//
//  ViewController.swift
//  FitnessBoss
//
//  Created by APPLE on 6/5/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    let login      =    UIButton()
    let register   =    UIButton()
    let textlable  =    UILabel()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        
        // adding subviews
        
        view.addSubview(login)
        view.addSubview(textlable)
        view.addSubview(register)
        
       
        //textlable programme
        
        textlable.text = "Regular Exercise To Keep Your Body Fit and Healty"
        textlable.textColor = .black
        textlable.font = UIFont(name: "Helvetica-Bold", size: 25)
        textlable.numberOfLines = 0
        textlable.textAlignment = .center
       // textlable.backgroundColor  = .yellow
        textlable.translatesAutoresizingMaskIntoConstraints = false
     
        
        //login programme
        
        login.setTitle("Login", for: .normal)
        login.backgroundColor = .black
        login.layer.cornerRadius = 10
        login.addTarget(self, action: #selector(loginProfile), for: .touchUpInside)
        login.translatesAutoresizingMaskIntoConstraints = false
        
        //register programme
        
        register.setTitle("Register", for: .normal)
        register.backgroundColor = .systemFill
        register.layer.cornerRadius = 10
        register.translatesAutoresizingMaskIntoConstraints = false
      
        
        
        loginButton()  // adding setup
    
    }
    
    // autolayouts and constraints
    
    func loginButton(){
        
      
//        NSLayoutConstraint.activate([
//
//            textlable.centerXAnchor.constraint(equalTo: view.centerXAnchor),
//            textlable.centerYAnchor.constraint(equalTo: view.centerYAnchor),
//            textlable.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
//            textlable.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
//            textlable.heightAnchor.constraint(equalToConstant: 100)
//        ])
//
        
        NSLayoutConstraint.activate([
    
                textlable.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                textlable.bottomAnchor.constraint(equalTo: login.topAnchor, constant: -60),
                textlable.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
                textlable.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            
            ])
         
        
        NSLayoutConstraint.activate([
            
            login.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            login.bottomAnchor.constraint(equalTo: register.topAnchor, constant: -10),
            login.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            login.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            login.heightAnchor.constraint(equalToConstant: 50 )
        ])
        
        NSLayoutConstraint.activate([
            
            register.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            register.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            register.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            register.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            register.heightAnchor.constraint(equalToConstant: 50 )
            
        ])
        
    }
    
    // for loginProfileBtnActn method declarartion
    
    @objc func loginProfile(){
        
        let vc = ProfileController()
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    
    
    }
    

