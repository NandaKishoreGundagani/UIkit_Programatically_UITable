//
//  SettingsController.swift
//  FitnessBoss
//
//  Created by APPLE on 6/6/23.
//

import UIKit

class SettingsController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        navigationItem.hidesBackButton = true

        // Do any additional setup after loading the view.
    }
    

}
