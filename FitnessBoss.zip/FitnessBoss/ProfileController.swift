//
//  ProfileController.swift
//  FitnessBoss
//
//  Created by APPLE on 6/5/23.
//

import UIKit

class ProfileController: UIViewController {
    var profileButton: UIButton!
    var greetLabel  =  UILabel()
    var nameLabel   =  UILabel()
    var topupButton =  UIButton()
    var topUplabel  =  UILabel()
    var transferBtn =  UIButton()
    var withdrawBtn =  UIButton()
    var othersBtn   =  UIButton()
    var transferlab =  UILabel()
    var withdrawlab =  UILabel()
    var otherslab   =  UILabel()
    var bellbtn     = UIButton()



    override func viewDidLoad() {
        super.viewDidLoad()
       
        view.backgroundColor = .white
        profileButton = UIButton(type: .system)
        navigationItem.hidesBackButton = true
        profilActivity()
       greetMe()
    
        nameLabel.text = "Nanda Kishore"
        nameLabel.textColor = .black
        nameLabel.font = UIFont(name: "Helvetica-Bold", size: 20)
        nameLabel.textAlignment = .center
        nameLabel.frame = CGRect(x: 35, y: -11, width: 200, height: 250)
        
        bellbtn = UIButton(type: .system)
        bellbtn.frame = CGRect(x: 300, y: 23, width: 100, height: 150)
        bellbtn.setImage(UIImage(systemName: "bell"), for: .normal)
        bellbtn.tintColor = .black

        othersBtn = UIButton(type: .system)
        othersBtn.frame = CGRect(x: 250, y: 250, width: 100, height: 150)
        othersBtn.setImage(UIImage(systemName: "ellipsis"), for: .normal)
        othersBtn.tintColor = .black
        otherslab.frame = CGRect(x: 250, y: 275, width: 100, height: 150)
        otherslab.text = "Others"
        otherslab.textAlignment = .center
        otherslab.font = UIFont.systemFont(ofSize: 12)
        otherslab.textColor = .black

        
        
        withdrawBtn = UIButton(type: .system)
        withdrawBtn.frame = CGRect(x: 160, y: 250, width: 100, height: 150)
        withdrawBtn.setImage(UIImage(systemName: "banknote"), for: .normal)
        withdrawBtn.tintColor = .black
        withdrawlab.frame = CGRect(x: 160, y: 275, width: 100, height: 150)
        withdrawlab.text = "Withdraw"
        withdrawlab.textAlignment = .center
        withdrawlab.font = UIFont.systemFont(ofSize: 12)
        withdrawlab.textColor = .black
        

        
        
        transferBtn = UIButton(type: .system)
        transferBtn.frame = CGRect(x: 75, y: 250, width: 100, height: 150)
        transferBtn.setImage(UIImage(systemName: "arrow.forward"), for: .normal)
        transferBtn.tintColor = .black
        transferlab.frame = CGRect(x: 75, y: 275, width: 100, height: 150)
        transferlab.text = "Transfer"
        transferlab.textAlignment = .center
        transferlab.font = UIFont.systemFont(ofSize: 12)
        transferlab.textColor = .black
        
        
        topupButton = UIButton(type: .system)
        topupButton.frame = CGRect(x: 10, y: 250, width: 100, height: 150)
        topupButton.setImage(UIImage(systemName: "square.and.arrow.up"), for: .normal)
        topupButton.tintColor = .black
        topUplabel.frame = CGRect(x: 10, y: 275, width: 100, height: 150)
        topUplabel.text = "TopUp"
        topUplabel.textAlignment = .center
        topUplabel.font = UIFont.systemFont(ofSize: 12)
        topUplabel.textColor = .black

        
        // Add label as subview of button
        view.addSubview(topUplabel)
        view.addSubview(topupButton)
        view.addSubview(greetLabel)
        view.addSubview(profileButton)
        view.addSubview(nameLabel)
        view.addSubview(transferlab)
        view.addSubview(transferBtn)
        view.addSubview(withdrawlab)
        view.addSubview(withdrawBtn)
        view.addSubview(otherslab)
        view.addSubview(othersBtn)
        view.addSubview(bellbtn)


    }
   func profilActivity(){
        profileButton.setImage(UIImage(systemName: "person.crop.circle.fill"), for: .normal)
        profileButton.frame = CGRect(x: -10, y: 90, width: 500, height: 500)
        profileButton.tintColor = .black
        profileButton.translatesAutoresizingMaskIntoConstraints = false
        profileButton.widthAnchor.constraint(equalToConstant: 80).isActive = true
        profileButton.heightAnchor.constraint(equalToConstant: 200).isActive = true
        profileButton.addTarget(self, action: #selector(activity), for: .touchUpInside)
        profileButton.translatesAutoresizingMaskIntoConstraints = false
     }
    
    func greetMe(){
        greetLabel.text = "Hi,Good Morning!"
        greetLabel.textColor = .black
        greetLabel.font = UIFont.preferredFont(forTextStyle: .body)
        greetLabel.numberOfLines = 1
        greetLabel.textAlignment = .center
        greetLabel.frame = CGRect(x: 30, y: -10, width: 200, height: 200)
    }
@objc func activity(){
    let settingsView = SettingsController()
    navigationController?.pushViewController(settingsView, animated: true)

}
}
